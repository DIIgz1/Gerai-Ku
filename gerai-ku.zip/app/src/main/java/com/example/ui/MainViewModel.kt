package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.AppRepository
import com.example.data.FruitEntity
import com.example.data.TransactionEntity
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class AppScreen {
    DASHBOARD,
    STOK_BUAH,
    BARANG_MASUK,
    PENJUALAN,
    BUAH_RUSAK,
    GRAFIK,
    RIWAYAT
}

data class DailyChartData(
    val label: String,
    val totalSales: Double,
    val totalProfit: Double
)

data class FruitStatus(
    val statusLabel: String,     // "Aman", "Mendekati kadaluarsa", "Kadaluarsa"
    val discountPercent: Double,  // 0.0, 0.1, 0.2, 1.0
    val discountPercentLabel: String, // "Tanpa Diskon", "Diskon 10%", "Diskon 20%", "Tidak Layak Jual"
    val daysRemaining: Int
)

fun FruitEntity.getStatusAndDiscount(currentTimestamp: Long = System.currentTimeMillis()): FruitStatus {
    val oneDayMs = 24 * 60 * 60 * 1000L
    val diff = expiryDate - currentTimestamp
    // Divide and round: if diff in millis is positive, we round up to nearest day.
    // If it's negative, it's expired.
    val days = if (diff >= 0) {
        (diff / oneDayMs).toInt() + 1
    } else {
        (diff / oneDayMs).toInt() - 1
    }

    val (label, pct, pctLabel) = when {
        days > 2 -> Triple("Aman", 0.0, "Tanpa Diskon")
        days == 2 -> Triple("Mendekati kadaluarsa", 0.10, "Diskon 10%")
        days == 1 -> Triple("Mendekati kadaluarsa", 0.20, "Diskon 20%")
        else -> Triple("Kadaluarsa", 1.00, "Tidak Layak Jual")
    }
    return FruitStatus(label, pct, pctLabel, days)
}

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = AppRepository(AppDatabase.getInstance(application).dao)

    // Current Navigation Screen
    val currentScreen = MutableStateFlow(AppScreen.DASHBOARD)

    // Data streams from Repository
    val fruitsState: StateFlow<List<FruitEntity>> = repository.allFruits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactionsState: StateFlow<List<TransactionEntity>> = repository.allTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // UI Toast or State messages
    private val _messageFlow = MutableSharedFlow<String>()
    val messageFlow = _messageFlow.asSharedFlow()

    // Combined Dashboard Stats
    val totalFruitTypes: StateFlow<Int> = fruitsState
        .map { list -> list.filter { it.stock > 0 }.map { it.name.lowercase().trim() }.distinct().size }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val totalStockSum: StateFlow<Double> = fruitsState
        .map { list -> list.filter { it.stock > 0 }.sumOf { it.stock } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalCapitalInStock: StateFlow<Double> = fruitsState
        .map { list -> list.sumOf { it.stock * it.buyPrice } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalSalesSum: StateFlow<Double> = transactionsState
        .map { list -> list.filter { it.type == "KELUAR" }.sumOf { it.totalAmount } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalProfitSum: StateFlow<Double> = transactionsState
        .map { list ->
            list.filter { it.type == "KELUAR" }.sumOf { txn ->
                val costOfGoods = txn.quantity * (txn.buyPricePerUnit ?: 0.0)
                txn.totalAmount - costOfGoods
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalDamagedQty: StateFlow<Double> = transactionsState
        .map { list -> list.filter { it.type == "RUSAK" }.sumOf { it.quantity } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    val totalDamagedLoss: StateFlow<Double> = transactionsState
        .map { list -> list.filter { it.type == "RUSAK" }.sumOf { it.totalAmount } }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0.0)

    // Automatic notifications alert for near expiry / expired fruits
    val expiryAlerts: StateFlow<List<FruitEntity>> = fruitsState
        .map { list ->
            val now = System.currentTimeMillis()
            list.filter {
                val status = it.getStatusAndDiscount(now)
                status.statusLabel != "Aman"
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lastDaysChartData: StateFlow<List<DailyChartData>> = transactionsState
        .map { list ->
            val result = mutableListOf<DailyChartData>()
            val sdf = java.text.SimpleDateFormat("dd/MM", java.util.Locale.getDefault())
            val msInDay = 24 * 60 * 60 * 1000L
            val now = System.currentTimeMillis()

            for (i in 6 downTo 0) {
                val targetDayStart = now - (i * msInDay)
                val dayLabel = sdf.format(java.util.Date(targetDayStart))

                val salesOnDay = list.filter {
                    it.type == "KELUAR" && sdf.format(java.util.Date(it.timestamp)) == dayLabel
                }

                val daySalesSum = salesOnDay.sumOf { it.totalAmount }
                val dayProfitSum = salesOnDay.sumOf { txn ->
                    val costOfGoods = txn.quantity * (txn.buyPricePerUnit ?: 0.0)
                    txn.totalAmount - costOfGoods
                }

                result.add(DailyChartData(
                    label = dayLabel,
                    totalSales = daySalesSum,
                    totalProfit = dayProfitSum
                ))
            }
            result
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Database Actions
    fun addGoodsEntry(
        name: String,
        quantity: Double,
        unit: String,
        buyPrice: Double,
        sellPrice: Double,
        entryDate: Long,
        expiryDate: Long
    ) {
        viewModelScope.launch {
            repository.logGoodsEntry(name, quantity, unit, buyPrice, sellPrice, entryDate, expiryDate)
            _messageFlow.emit("Barang masuk dicatat: $name ($quantity $unit)")
        }
    }

    fun sellFruit(fruitId: Int, quantity: Double, soldPrice: Double, timestamp: Long) {
        viewModelScope.launch {
            val success = repository.logSale(fruitId, quantity, soldPrice, timestamp)
            if (success) {
                _messageFlow.emit("Penjualan dicatat!")
            } else {
                _messageFlow.emit("Gagal mencatat penjualan. Stok tidak mencukupi.")
            }
        }
    }

    fun reportDamage(fruitId: Int, quantity: Double, reason: String, timestamp: Long) {
        viewModelScope.launch {
            val success = repository.logDamage(fruitId, quantity, reason, timestamp)
            if (success) {
                _messageFlow.emit("Buah rusak/busuk dicatat!")
            } else {
                _messageFlow.emit("Gagal mencatat buah rusak. Stok tidak mencukupi.")
            }
        }
    }

    fun editFruitPrices(fruitId: Int, newBuyPrice: Double, newSellPrice: Double) {
        viewModelScope.launch {
            val fruit = repository.getFruitById(fruitId)
            if (fruit != null) {
                repository.updateFruit(fruit.copy(buyPrice = newBuyPrice, sellPrice = newSellPrice))
                _messageFlow.emit("Harga berhasil diperbarui!")
            } else {
                _messageFlow.emit("Buah tidak ditemukan.")
            }
        }
    }

    fun resetAllData() {
        viewModelScope.launch {
            repository.clearAllData()
            _messageFlow.emit("Semua data berhasil di-reset!")
        }
    }

    fun setScreen(screen: AppScreen) {
        currentScreen.value = screen
    }
}
