package com.example.ui

import androidx.compose.animation.*
import androidx.compose.ui.graphics.toArgb
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.FruitEntity
import com.example.data.TransactionEntity
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppUi(viewModel: MainViewModel) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val fruits by viewModel.fruitsState.collectAsStateWithLifecycle()
    val transactions by viewModel.transactionsState.collectAsStateWithLifecycle()
    val expiryAlerts by viewModel.expiryAlerts.collectAsStateWithLifecycle()
    
    val snackbarHostState = remember { SnackbarHostState() }
    
    // Auto alerts popup on launch
    var hasShownLaunchAlert by remember { mutableStateOf(false) }
    if (expiryAlerts.isNotEmpty() && !hasShownLaunchAlert) {
        AlertDialog(
            onDismissRequest = { hasShownLaunchAlert = true },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.setScreen(AppScreen.STOK_BUAH)
                        hasShownLaunchAlert = true
                    }
                ) {
                    Text("Periksa Stok")
                }
            },
            dismissButton = {
                TextButton(onClick = { hasShownLaunchAlert = true }) {
                    Text("Tutup")
                }
            },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.NotificationsActive,
                        contentDescription = "Peringatan",
                        tint = MaterialTheme.colorScheme.error,
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Peringatan Kadaluarsa!")
                }
            },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 200.dp)) {
                    item {
                        Text(
                            "Ada beberapa jenis buah yang mendekati kadaluarsa atau sudah kadaluarsa:",
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }
                    items(expiryAlerts) { fruit ->
                        val status = fruit.getStatusAndDiscount()
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${fruit.name} (${fruit.stock} ${fruit.unit})",
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            val badgeColor = if (status.daysRemaining <= 0) {
                                MaterialTheme.colorScheme.error
                            } else {
                                Color(0xFFEF6C00) // Orange
                            }
                            Text(
                                text = status.statusLabel,
                                color = badgeColor,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        )
    }

    // Launch coroutine listener for Toast/Snackbar messages
    LaunchedEffect(Unit) {
        viewModel.messageFlow.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Store,
                        contentDescription = "Gerai Ku Logo",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(32.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = "Gerai Ku",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Text(
                    text = "Aplikasi UMKM Buah",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
                )
                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                // Navigation Items
                val navItems = listOf(
                    AppScreen.DASHBOARD to "Dashboard" to Icons.Default.Dashboard,
                    AppScreen.STOK_BUAH to "Stok Buah" to Icons.Default.Inventory,
                    AppScreen.BARANG_MASUK to "Barang Masuk" to Icons.Default.Input,
                    AppScreen.PENJUALAN to "Penjualan / Keluar" to Icons.Default.ShoppingCart,
                    AppScreen.BUAH_RUSAK to "Buah Rusak / Busuk" to Icons.Default.Delete,
                    AppScreen.GRAFIK to "Grafik Penjualan" to Icons.Default.BarChart,
                    AppScreen.RIWAYAT to "Riwayat Transaksi" to Icons.Default.History
                )

                navItems.forEach { (screenMap, icon) ->
                    val (screen, label) = screenMap
                    val isSelected = currentScreen == screen
                    NavigationDrawerItem(
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) },
                        selected = isSelected,
                        onClick = {
                            viewModel.setScreen(screen)
                            scope.launch { drawerState.close() }
                        },
                        colors = NavigationDrawerItemDefaults.colors(
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            selectedIconColor = MaterialTheme.colorScheme.primary,
                            selectedTextColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier
                            .padding(NavigationDrawerItemDefaults.ItemPadding)
                            .testTag("nav_item_${screen.name.lowercase()}")
                    )
                }
            }
        }
    ) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu", tint = Color(0xFF2D5A27))
                        }
                    },
                    title = {
                        Column(modifier = Modifier.padding(start = 4.dp)) {
                            Text(
                                text = "Gerai Ku",
                                fontWeight = FontWeight.Bold,
                                fontSize = 21.sp,
                                color = Color(0xFF2D5A27)
                            )
                            val subtitleLabel = when (currentScreen) {
                                AppScreen.DASHBOARD -> "Ringkasan Dashboard"
                                AppScreen.STOK_BUAH -> "Stok & Keterediaan"
                                AppScreen.BARANG_MASUK -> "Barang Masuk Baru"
                                AppScreen.PENJUALAN -> "Catat Penjualan Toko"
                                AppScreen.BUAH_RUSAK -> "Laporan Kerugian & Busuk"
                                AppScreen.GRAFIK -> "Tren Penjualan 7 Hari"
                                AppScreen.RIWAYAT -> "Riwayat Aliran Transaksi"
                            }
                            Text(
                                text = subtitleLabel.uppercase(),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray,
                                letterSpacing = 0.5.sp
                            )
                        }
                    },
                    actions = {
                        Box(
                            modifier = Modifier
                                .padding(end = 16.dp)
                                .size(36.dp)
                                .background(Color(0xFFE8F3E6), RoundedCornerShape(18.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(18.dp)
                                    .background(Color.Transparent, RoundedCornerShape(9.dp))
                                    .border(2.dp, Color(0xFF2D5A27), RoundedCornerShape(9.dp))
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Color.White,
                        titleContentColor = Color(0xFF2D5A27)
                    )
                )
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(MaterialTheme.colorScheme.background)
            ) {
                // Render Page depending on State
                AnimatedContent(
                    targetState = currentScreen,
                    transitionSpec = {
                        fadeIn() togetherWith fadeOut()
                    },
                    label = "page_transition"
                ) { screen ->
                    when (screen) {
                        AppScreen.DASHBOARD -> DashboardScreen(viewModel)
                        AppScreen.STOK_BUAH -> StokBuahScreen(viewModel)
                        AppScreen.BARANG_MASUK -> BarangMasukScreen(viewModel)
                        AppScreen.PENJUALAN -> PenjualanScreen(viewModel)
                        AppScreen.BUAH_RUSAK -> BuahRusakScreen(viewModel)
                        AppScreen.GRAFIK -> GrafikScreen(viewModel)
                        AppScreen.RIWAYAT -> RiwayatScreen(viewModel)
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------
// HELPERS
// -----------------------------------------------------
fun formatRupiah(amount: Double): String {
    val format = NumberFormat.getCurrencyInstance(Locale("in", "ID"))
    return format.format(amount).replace("Rp", "Rp ").replace(",00", "")
}

fun formatDateTime(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale("in", "ID"))
    return sdf.format(Date(timestamp))
}

fun formatDate(timestamp: Long): String {
    val sdf = SimpleDateFormat("dd MMM yyyy", Locale("in", "ID"))
    return sdf.format(Date(timestamp))
}

@Composable
fun DatePickerDialogButton(
    label: String,
    timestamp: Long,
    onDateSelected: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val calendar = Calendar.getInstance().apply {
        timeInMillis = timestamp
    }
    
    val dateStr = formatDate(timestamp)
    
    OutlinedButton(
        onClick = {
            android.app.DatePickerDialog(
                context,
                { _, year, month, dayOfMonth ->
                    val selectedCal = Calendar.getInstance()
                    selectedCal.set(year, month, dayOfMonth)
                    onDateSelected(selectedCal.timeInMillis)
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
            ).show()
        },
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp),
        shape = RoundedCornerShape(4.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = MaterialTheme.colorScheme.onSurfaceVariant
        )
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(text = "$label: $dateStr", fontSize = 16.sp)
            Icon(Icons.Default.CalendarMonth, contentDescription = "Pilih Tanggal")
        }
    }
}

// -----------------------------------------------------
// 1. DASHBOARD SCREEN
// -----------------------------------------------------
@Composable
fun DashboardScreen(viewModel: MainViewModel) {
    val totalTypes by viewModel.totalFruitTypes.collectAsStateWithLifecycle()
    val totalStockSum by viewModel.totalStockSum.collectAsStateWithLifecycle()
    val totalCapitalInStock by viewModel.totalCapitalInStock.collectAsStateWithLifecycle()
    val totalSalesSum by viewModel.totalSalesSum.collectAsStateWithLifecycle()
    val totalProfitSum by viewModel.totalProfitSum.collectAsStateWithLifecycle()
    val totalDamagedQty by viewModel.totalDamagedQty.collectAsStateWithLifecycle()
    val totalDamagedLoss by viewModel.totalDamagedLoss.collectAsStateWithLifecycle()
    val expiryAlerts by viewModel.expiryAlerts.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Welcome Card (Professional Polish Style)
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = Color(0xFFE8F3E6) // Match design #E8F3E6
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(Color.White, RoundedCornerShape(20.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.Storefront,
                                contentDescription = null,
                                tint = Color(0xFF2D5A27),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = "Gerai Ku",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2D5A27)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Kelola usaha buah Anda secara cerdas. Analisis omzet penjualan, laba bersih otomatis, diskon kadaluarsa, serta pemantauan stok real-time.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF334155),
                        lineHeight = 20.sp
                    )
                }
            }
        }

        // Stats Title
        item {
            Column(modifier = Modifier.padding(horizontal = 4.dp)) {
                Text(
                    text = "Ringkasan Bisnis",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
                Text(
                    text = "STATUS KEUANGAN & STOK TERKINI",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray,
                    letterSpacing = 0.5.sp
                )
            }
        }

        // Stats Grid in 2 Columns matching the Tailwind layout
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Total Jenis Buah
                    StatCard(
                        title = "Jenis Buah",
                        value = "$totalTypes Jenis",
                        icon = Icons.Default.Category,
                        color = Color(0xFF2D5A27),
                        modifier = Modifier.weight(1f)
                    )
                    // Total Stok
                    StatCard(
                        title = "Total Stok",
                        value = "${String.format("%.1f", totalStockSum)} kg",
                        icon = Icons.Default.Inventory2,
                        color = Color(0xFF475569),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Active Capital
                    StatCard(
                        title = "Total Modal",
                        value = formatRupiah(totalCapitalInStock),
                        icon = Icons.Default.AccountBalanceWallet,
                        color = Color(0xFF475569),
                        modifier = Modifier.weight(1f)
                    )
                    // Total Penjualan
                    StatCard(
                        title = "Total Omzet",
                        value = formatRupiah(totalSalesSum),
                        icon = Icons.Default.TrendingUp,
                        color = Color(0xFF2D5A27),
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Total Keuntungan (Polished positive green styling)
                    StatCard(
                        title = "Keuntungan",
                        value = formatRupiah(totalProfitSum),
                        icon = Icons.Default.Payments,
                        color = Color(0xFF2D5A27),
                        modifier = Modifier.weight(1f),
                        containerColor = Color(0xFFF0F9EE), // BG #F0F9EE
                        borderColor = Color(0xFFD8EED4),     // Border #D8EED4
                        textColor = Color(0xFF2D5A27)       // Text #2D5A27
                    )
                    // Total Buah Rusak (Polished critical red styling)
                    StatCard(
                        title = "Buah Rusak",
                        value = "${String.format("%.1f", totalDamagedQty)} kg",
                        icon = Icons.Default.DeleteOutline,
                        color = Color(0xFF991B1B),
                        modifier = Modifier.weight(1f),
                        containerColor = Color(0xFFFEF2F2), // BG #FEF2F2
                        borderColor = Color(0xFFFEE2E2),     // Border #FEE2E2
                        textColor = Color(0xFF991B1B)       // Text #991B1B
                    )
                }
            }
        }

        // Quick Entry Actions Header
        item {
            Column(modifier = Modifier.padding(horizontal = 4.dp, vertical = 4.dp)) {
                Text(
                    "Akses Cepat",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )
                Text(
                    "PENCATATAN KASIR CEPAT",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.Gray,
                    letterSpacing = 0.5.sp
                )
            }
        }

        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                OutlinedButton(
                    onClick = { viewModel.setScreen(AppScreen.BARANG_MASUK) },
                    modifier = Modifier.weight(1f).height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = Color(0xFF2D5A27)
                    ),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF2D5A27))
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Barang Masuk", maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                Button(
                    onClick = { viewModel.setScreen(AppScreen.PENJUALAN) },
                    modifier = Modifier.weight(1f).height(48.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF2D5A27),
                        contentColor = Color.White
                    )
                ) {
                    Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Jual Buah", maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }
        }

        // Butuh Perhatian Section / Urgent alerts list
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.padding(top = 4.dp)) {
                Column(modifier = Modifier.padding(horizontal = 4.dp)) {
                    Text(
                        text = "Butuh Perhatian",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                    Text(
                        text = "peringatan kedaluwarsa & rekomendasi".uppercase(),
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Gray,
                        letterSpacing = 0.5.sp
                    )
                }

                if (expiryAlerts.isEmpty()) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(Color(0xFFF0F9EE), RoundedCornerShape(18.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    Icons.Default.Check,
                                    contentDescription = null,
                                    tint = Color(0xFF2D5A27),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Text(
                                "Semua Stok Buah Aman!\nTidak ada produk buah mendekati kadaluarsa.",
                                fontSize = 13.sp,
                                color = Color(0xFF475569),
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        expiryAlerts.forEach { fruit ->
                            val status = fruit.getStatusAndDiscount()
                            val isExpired = status.daysRemaining <= 0

                            val bgCol = if (isExpired) Color(0xFFFEF2F2) else Color(0xFFFFFBEB)
                            val borderCol = if (isExpired) Color(0xFFFEE2E2) else Color(0xFFFEF3C7)
                            val textCol = if (isExpired) Color(0xFF991B1B) else Color(0xFFB45309)

                            // Fruit emoji mapper dynamically
                            val lowerName = fruit.name.lowercase()
                            val emoji = when {
                                lowerName.contains("apel") -> "🍎"
                                lowerName.contains("pisang") -> "🍌"
                                lowerName.contains("jeruk") -> "🍊"
                                lowerName.contains("mangga") -> "🥭"
                                lowerName.contains("melon") -> "🍈"
                                lowerName.contains("semangka") -> "🍉"
                                lowerName.contains("anggur") -> "🍇"
                                lowerName.contains("strawberry") || lowerName.contains("stroberi") -> "🍓"
                                lowerName.contains("nanas") -> "🍍"
                                lowerName.contains("pepaya") -> "🥭"
                                lowerName.contains("durian") -> "🍍"
                                else -> "🍎"
                            }

                            Card(
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = bgCol),
                                border = androidx.compose.foundation.BorderStroke(1.dp, borderCol),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.setScreen(AppScreen.STOK_BUAH) }
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Box(
                                            modifier = Modifier
                                                .size(44.dp)
                                                .background(Color.White, RoundedCornerShape(12.dp))
                                                .border(1.dp, borderCol, RoundedCornerShape(12.dp)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(emoji, fontSize = 22.sp)
                                        }
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Column {
                                            Text(
                                                text = fruit.name,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 15.sp,
                                                color = Color(0xFF0F172A)
                                            )
                                            Text(
                                                text = if (isExpired) "Sudah Kadaluarsa" else "${status.daysRemaining} Hari Lagi Kadaluarsa",
                                                fontSize = 11.sp,
                                                color = textCol,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            text = "REKOMENDASI",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color.Gray.copy(alpha = 0.8f),
                                            letterSpacing = 0.5.sp
                                        )
                                        val recText = if (isExpired) {
                                            "Catat Busuk"
                                        } else {
                                            "Diskon ${(status.discountPercent * 100).toInt()}%"
                                        }
                                        val recColor = if (isExpired) Color(0xFF991B1B) else Color(0xFF2D5A27)
                                        Text(
                                            text = recText,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = recColor
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatCard(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    containerColor: Color = Color.White,
    borderColor: Color = Color(0xFFE2E8F0),
    textColor: Color = Color(0xFF0F172A)
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = containerColor
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = title.uppercase(),
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (containerColor == Color.White) Color.Gray else textColor.copy(alpha = 0.8f),
                    letterSpacing = 0.5.sp
                )
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(16.dp)
                )
            }
            Text(
                text = value,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = textColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// -----------------------------------------------------
// 2. STOK BUAH SCREEN
// -----------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StokBuahScreen(viewModel: MainViewModel) {
    val fruits by viewModel.fruitsState.collectAsStateWithLifecycle()
    var searchQuery by remember { mutableStateOf("") }
    
    // Filtering active fruits
    val filteredFruits = fruits.filter {
        it.name.contains(searchQuery, ignoreCase = true)
    }

    // Modal state for price editing
    var editingFruit by remember { mutableStateOf<FruitEntity?>(null) }
    var inputBuyPrice by remember { mutableStateOf("") }
    var inputSellPrice by remember { mutableStateOf("") }

    if (editingFruit != null) {
        Dialog(onDismissRequest = { editingFruit = null }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "Edit Harga - ${editingFruit?.name}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    OutlinedTextField(
                        value = inputBuyPrice,
                        onValueChange = { inputBuyPrice = it },
                        label = { Text("Harga Beli Per Satuan (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = inputSellPrice,
                        onValueChange = { inputSellPrice = it },
                        label = { Text("Harga Jual Per Satuan (Rp)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { editingFruit = null }) {
                            Text("Batal")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val buy = inputBuyPrice.toDoubleOrNull()
                                val sell = inputSellPrice.toDoubleOrNull()
                                if (buy != null && sell != null && buy > 0 && sell > 0) {
                                    viewModel.editFruitPrices(editingFruit!!.id, buy, sell)
                                    editingFruit = null
                                }
                            }
                        ) {
                            Text("Simpan")
                        }
                    }
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Search bar & Header row
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Daftar Stok Buah",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            FilledTonalButton(
                onClick = { viewModel.setScreen(AppScreen.BARANG_MASUK) },
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Beli Stok", fontSize = 12.sp)
            }
        }

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Cari buah...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = MaterialTheme.colorScheme.primary,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline
            )
        )

        if (filteredFruits.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        Icons.Default.HourglassEmpty,
                        contentDescription = null,
                        modifier = Modifier.size(48.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                    )
                    Text(
                        text = if (searchQuery.isEmpty()) "Stok buah Anda kosong.\nSilakan tambah barang masuk!" else "Tidak ada buah dengan kata kunci tersebut.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize().weight(1f)
            ) {
                items(filteredFruits) { fruit ->
                    FruitCard(
                        fruit = fruit,
                        onEditClick = {
                            editingFruit = fruit
                            inputBuyPrice = fruit.buyPrice.toString()
                            inputSellPrice = fruit.sellPrice.toString()
                        },
                        onSellQuickClick = {
                            viewModel.setScreen(AppScreen.PENJUALAN)
                        },
                        onDamageQuickClick = {
                            viewModel.setScreen(AppScreen.BUAH_RUSAK)
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun FruitCard(
    fruit: FruitEntity,
    onEditClick: () -> Unit,
    onSellQuickClick: () -> Unit,
    onDamageQuickClick: () -> Unit
) {
    val status = fruit.getStatusAndDiscount()
    val isExpired = status.daysRemaining <= 0
    val isClose = status.daysRemaining in 1..2
    
    val borderStrokeColor = when {
        isExpired -> MaterialTheme.colorScheme.error
        isClose -> Color(0xFFEF6C00) // Orange
        else -> MaterialTheme.colorScheme.outlineVariant
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, borderStrokeColor)
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // Header: Name and Expiry Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = fruit.name,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "Masuk: ${formatDate(fruit.entryDate)}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Badge Status Kadaluarsa
                val (bgBadge, fgBadge, labelBadge) = when {
                    isExpired -> Triple(MaterialTheme.colorScheme.errorContainer, MaterialTheme.colorScheme.onErrorContainer, "Kadaluarsa")
                    isClose -> Triple(Color(0xFFFFF3E0), Color(0xFFE65100), "Sisa ${status.daysRemaining} hari")
                    else -> Triple(Color(0xFFE8F5E9), Color(0xFF2E7D32), "Aman: ${status.daysRemaining} hari")
                }
                
                AssistChip(
                    onClick = { },
                    label = { Text(labelBadge, fontWeight = FontWeight.SemiBold, fontSize = 11.sp) },
                    colors = AssistChipDefaults.assistChipColors(
                        containerColor = bgBadge,
                        labelColor = fgBadge
                    ),
                    border = null,
                    modifier = Modifier.height(26.dp)
                )
            }

            // Divider
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

            // Quantities, pricing & Discount suggestion
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Jumlah Stok", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        "${String.format("%.1f", fruit.stock)} ${fruit.unit}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                }
                Column {
                    Text("Harga Beli / Satuan", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(formatRupiah(fruit.buyPrice), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                }
                Column {
                    Text("Harga Jual / Satuan", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(formatRupiah(fruit.sellPrice), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                }
            }

            // Recommended Discount section if applicable
            if (status.discountPercent > 0.0) {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isExpired) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f) else Color(0xFFFFF3E0)
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = if (isExpired) Icons.Default.Cancel else Icons.Default.LocalOffer,
                                contentDescription = null,
                                tint = if (isExpired) MaterialTheme.colorScheme.error else Color(0xFFEF6C00),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isExpired) "Segera Buang / Sampah" else "Rekomendasi ${status.discountPercentLabel}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isExpired) MaterialTheme.colorScheme.error else Color(0xFFEF6C00)
                            )
                        }
                        
                        if (!isExpired) {
                            val discounted = fruit.sellPrice * (1 - status.discountPercent)
                            Text(
                                text = "Harga Diskon: ${formatRupiah(discounted)}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFEF6C00)
                            )
                        }
                    }
                }
            }

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onEditClick) {
                    Icon(
                        Icons.Default.Edit,
                        contentDescription = "Edit Harga",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
                
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onDamageQuickClick,
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        ),
                        modifier = Modifier.height(36.dp),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp)
                    ) {
                        Text("Catat Busuk", fontSize = 12.sp)
                    }

                    Button(
                        onClick = onSellQuickClick,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier.height(36.dp),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp)
                    ) {
                        Text("Jual", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

// -----------------------------------------------------
// 3. BARANG MASUK SCREEN (GOODS ENTRY)
// -----------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BarangMasukScreen(viewModel: MainViewModel) {
    var name by remember { mutableStateOf("") }
    var quantityInput by remember { mutableStateOf("") }
    var unitValue by remember { mutableStateOf("kg") }
    var buyPriceInput by remember { mutableStateOf("") }
    var sellPriceInput by remember { mutableStateOf("") }
    
    val now = System.currentTimeMillis()
    var entryDate by remember { mutableStateOf(now) }
    // Default expiry: 7 days from now
    var expiryDate by remember { mutableStateOf(now + (7L * 24 * 60 * 60 * 1000)) }

    // Helpers for checking
    val quantity = quantityInput.toDoubleOrNull() ?: 0.0
    val buyPrice = buyPriceInput.toDoubleOrNull() ?: 0.0
    val sellPrice = sellPriceInput.toDoubleOrNull() ?: 0.0
    val totalSpend = quantity * buyPrice

    // Dropdown satun state
    var unitExpanded by remember { mutableStateOf(false) }
    val units = listOf("kg", "buah", "pack")

    // Validation
    val isFormValid = name.isNotBlank() && quantity > 0 && buyPrice > 0 && sellPrice > 0 && expiryDate > entryDate

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "Catat Barang Masuk (Beli Buah Baru)",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Fruit Name Input
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Nama Buah") },
                        placeholder = { Text("e.g. Apel Malang, Pisang Raja") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    // Quantity and Unit Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = quantityInput,
                            onValueChange = { quantityInput = it },
                            label = { Text("Jumlah Masuk") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1.5f),
                            singleLine = true
                        )

                        // Custom dropdown for Satuan
                        Box(modifier = Modifier.weight(1f).padding(top = 4.dp)) {
                            OutlinedTextField(
                                value = unitValue,
                                onValueChange = {},
                                label = { Text("Satuan") },
                                readOnly = true,
                                trailingIcon = {
                                    IconButton(onClick = { unitExpanded = true }) {
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().clickable { unitExpanded = true }
                            )
                            DropdownMenu(
                                expanded = unitExpanded,
                                onDismissRequest = { unitExpanded = false }
                            ) {
                                units.forEach { unit ->
                                    DropdownMenuItem(
                                        text = { Text(unit) },
                                        onClick = {
                                            unitValue = unit
                                            unitExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Pricing Inputs
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = buyPriceInput,
                            onValueChange = { buyPriceInput = it },
                            label = { Text("Harga Beli / Unit") },
                            placeholder = { Text("Modal") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )

                        OutlinedTextField(
                            value = sellPriceInput,
                            onValueChange = { sellPriceInput = it },
                            label = { Text("Harga Jual / Unit") },
                            placeholder = { Text("Jual") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    // Dates select
                    DatePickerDialogButton(
                        label = "Tanggal Barang Masuk",
                        timestamp = entryDate,
                        onDateSelected = { timestamp ->
                            entryDate = timestamp
                            if (expiryDate <= entryDate) {
                                expiryDate = entryDate + (7L * 24 * 60 * 60 * 1000)
                            }
                        }
                    )

                    DatePickerDialogButton(
                        label = "Tanggal Masa Kadaluarsa",
                        timestamp = expiryDate,
                        onDateSelected = { timestamp ->
                            expiryDate = timestamp
                        }
                    )
                }
            }
        }

        // Live calculation summary
        if (quantity > 0 && buyPrice > 0) {
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Total Pembayaran Modal", fontSize = 12.sp, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Text(
                                text = formatRupiah(totalSpend),
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Icon(Icons.Default.Calculate, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    }
                }
            }
        }

        // Submit Button
        item {
            Button(
                onClick = {
                    if (isFormValid) {
                        viewModel.addGoodsEntry(
                            name = name,
                            quantity = quantity,
                            unit = unitValue,
                            buyPrice = buyPrice,
                            sellPrice = sellPrice,
                            entryDate = entryDate,
                            expiryDate = expiryDate
                        )
                        // Clear inputs
                        name = ""
                        quantityInput = ""
                        buyPriceInput = ""
                        sellPriceInput = ""
                    }
                },
                enabled = isFormValid,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.AddTask, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Simpan Barang Masuk", fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            
            // Helpful tip text if not valid
            if (!isFormValid) {
                Text(
                    text = "* Harap isi seluruh form dengan benar. Tanggal kadaluarsa harus terjadi setelah tanggal masuk barang.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.error,
                    modifier = Modifier.padding(top = 8.dp),
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

// -----------------------------------------------------
// 4. PENJUALAN SCREEN (GOODS OUT / SALES)
// -----------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PenjualanScreen(viewModel: MainViewModel) {
    val fruits by viewModel.fruitsState.collectAsStateWithLifecycle()
    
    // Choose available fruit options
    val fruitOptions = fruits.filter { it.stock > 0 }

    var selectedIndex by remember { mutableStateOf(-1) }
    var quantityInput by remember { mutableStateOf("") }
    var salesPriceInput by remember { mutableStateOf("") }
    
    var fruitDropdownExpanded by remember { mutableStateOf(false) }

    val selectedFruit = if (selectedIndex in fruitOptions.indices) fruitOptions[selectedIndex] else null
    val quantity = quantityInput.toDoubleOrNull() ?: 0.0
    val userSalesPrice = salesPriceInput.toDoubleOrNull() ?: 0.0

    // Auto calculate recommended price based on expiry discount
    LaunchedEffect(selectedFruit) {
        if (selectedFruit != null) {
            val status = selectedFruit.getStatusAndDiscount()
            val finalPrice = selectedFruit.sellPrice * (1.0 - status.discountPercent)
            salesPriceInput = finalPrice.toString()
        }
    }

    val isFormValid = selectedFruit != null && quantity > 0 && quantity <= selectedFruit.stock && userSalesPrice > 0

    // Live preview Calculations
    val totalRevenue = quantity * userSalesPrice
    val originalCost = if (selectedFruit != null) quantity * selectedFruit.buyPrice else 0.0
    val expectedProfit = totalRevenue - originalCost

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "Catat Penjualan Buah (Barang Keluar)",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        if (fruitOptions.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Tidak Ada Stok Buah Tersedia Untuk Dijual",
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "Tambahkan stok terlebih dahulu di menu 'Barang Masuk'.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.8f),
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { viewModel.setScreen(AppScreen.BARANG_MASUK) },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Beli Stok Sekarang")
                        }
                    }
                }
            }
        } else {
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        
                        // Select Fruit Dropdown
                        Box(modifier = Modifier.fillMaxWidth()) {
                            val triggerName = selectedFruit?.let { "${it.name} (Tersedia: ${String.format("%.1f", it.stock)} ${it.unit})" } ?: "Pilih Buah Dari Stok"
                            OutlinedTextField(
                                value = triggerName,
                                onValueChange = {},
                                label = { Text("Pilih Buah") },
                                readOnly = true,
                                leadingIcon = { Icon(Icons.Default.List, contentDescription = null) },
                                trailingIcon = {
                                    IconButton(onClick = { fruitDropdownExpanded = true }) {
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().clickable { fruitDropdownExpanded = true }
                            )
                            DropdownMenu(
                                expanded = fruitDropdownExpanded,
                                onDismissRequest = { fruitDropdownExpanded = false },
                                modifier = Modifier.fillMaxWidth(0.9f)
                            ) {
                                fruitOptions.forEachIndexed { index, opt ->
                                    val status = opt.getStatusAndDiscount()
                                    val formattedExp = if (status.daysRemaining <= 0) "KADALUARSA" else "${status.daysRemaining} hari lagi"
                                    DropdownMenuItem(
                                        text = {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("${opt.name} (${String.format("%.1f", opt.stock)} ${opt.unit})")
                                                Text(
                                                    text = if (status.discountPercent > 0.0) "${status.statusLabel} (-${(status.discountPercent * 100).toInt()}%)" else "Aman",
                                                    color = if (status.daysRemaining <= 0) MaterialTheme.colorScheme.error else Color(0xFFEF6C00),
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        },
                                        onClick = {
                                            selectedIndex = index
                                            fruitDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        if (selectedFruit != null) {
                            val status = selectedFruit.getStatusAndDiscount()
                            // Quantity
                            OutlinedTextField(
                                value = quantityInput,
                                onValueChange = { quantityInput = it },
                                label = { Text("Jumlah Terjual (Maks: ${String.format("%.1f", selectedFruit.stock)} ${selectedFruit.unit})") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                placeholder = { Text("0.0") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            // Price input
                            OutlinedTextField(
                                value = salesPriceInput,
                                onValueChange = { salesPriceInput = it },
                                label = { Text("Harga Jual Per Satuan (Rp)") },
                                placeholder = { Text(selectedFruit.sellPrice.toString()) },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            // Show info alert for validation constraints if any
                            if (quantity > selectedFruit.stock) {
                                Text(
                                    "Jumlah terjual tidak boleh melebihi stok tersedia (${selectedFruit.stock} ${selectedFruit.unit})!",
                                    color = MaterialTheme.colorScheme.error,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Expiry recommendation alert info
                            if (status.discountPercent > 0.0) {
                                Text(
                                    text = "* Rekomendasi Diskon: produk ${status.statusLabel} dengan diskon ${(status.discountPercent * 100).toInt()}%. Harga terisi otomatis.",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFE65100)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Live calculation metrics
        if (isFormValid && selectedFruit != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Pembayaran Pelanggan", fontSize = 13.sp)
                            Text(formatRupiah(totalRevenue), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Modal Barang Terjual", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(formatRupiah(originalCost), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        HorizontalDivider(color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.1f))
                        Row(
                            modifier = Modifier.fillMaxWidth(), 
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Laba Bersih Transaksi", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            val profitColor = if (expectedProfit >= 0) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                            Text(
                                formatRupiah(expectedProfit), 
                                fontWeight = FontWeight.Bold, 
                                fontSize = 18.sp,
                                color = profitColor
                            )
                        }
                    }
                }
            }
        }

        // Save Button
        if (fruitOptions.isNotEmpty()) {
            item {
                Button(
                    onClick = {
                        if (isFormValid && selectedFruit != null) {
                            viewModel.sellFruit(
                                fruitId = selectedFruit.id,
                                quantity = quantity,
                                soldPrice = userSalesPrice,
                                timestamp = System.currentTimeMillis()
                            )
                            // Clear fields
                            selectedIndex = -1
                            quantityInput = ""
                            salesPriceInput = ""
                        }
                    },
                    enabled = isFormValid,
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Sell, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Catat Penjualan", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}

// -----------------------------------------------------
// 5. BUAH RUSAK / BUSUK SCREEN
// -----------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuahRusakScreen(viewModel: MainViewModel) {
    val fruits by viewModel.fruitsState.collectAsStateWithLifecycle()
    
    // Fruits available in stocks
    val fruitOptions = fruits.filter { it.stock > 0 }

    var selectedIndex by remember { mutableStateOf(-1) }
    var quantityInput by remember { mutableStateOf("") }
    var selectedReason by remember { mutableStateOf("busuk") }

    var fruitDropdownExpanded by remember { mutableStateOf(false) }
    var reasonDropdownExpanded by remember { mutableStateOf(false) }

    val reasons = listOf("busuk", "rusak", "terlalu matang", "tidak layak jual", "lainnya")

    val selectedFruit = if (selectedIndex in fruitOptions.indices) fruitOptions[selectedIndex] else null
    val quantity = quantityInput.toDoubleOrNull() ?: 0.0

    val isFormValid = selectedFruit != null && quantity > 0 && quantity <= selectedFruit.stock

    val totalLoss = if (selectedFruit != null) quantity * selectedFruit.buyPrice else 0.0

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Text(
                "Catat Buah Rusak / Busuk (Kerugian)",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        if (fruitOptions.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(48.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Stok Buah Kosong",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Anda belum memiliki buah aktif di dalam stok untuk dilaporkan rusak.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }
            }
        } else {
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        
                        // Select Fruit dropdown
                        Box(modifier = Modifier.fillMaxWidth()) {
                            val triggerName = selectedFruit?.let { "${it.name} (Tersedia: ${String.format("%.1f", it.stock)} ${it.unit})" } ?: "Pilih Buah Dari Stok"
                            OutlinedTextField(
                                value = triggerName,
                                onValueChange = {},
                                label = { Text("Pilih Buah") },
                                readOnly = true,
                                leadingIcon = { Icon(Icons.Default.List, contentDescription = null) },
                                trailingIcon = {
                                    IconButton(onClick = { fruitDropdownExpanded = true }) {
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().clickable { fruitDropdownExpanded = true }
                            )
                            DropdownMenu(
                                expanded = fruitDropdownExpanded,
                                onDismissRequest = { fruitDropdownExpanded = false },
                                modifier = Modifier.fillMaxWidth(0.9f)
                            ) {
                                fruitOptions.forEachIndexed { index, opt ->
                                    val status = opt.getStatusAndDiscount()
                                    DropdownMenuItem(
                                        text = {
                                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                                Text("${opt.name} (${String.format("%.1f", opt.stock)} ${opt.unit})")
                                                if (status.daysRemaining <= 0) {
                                                    Text("KADALUARSA", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                                }
                                            }
                                        },
                                        onClick = {
                                            selectedIndex = index
                                            fruitDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }

                        if (selectedFruit != null) {
                            // Quantity
                            OutlinedTextField(
                                value = quantityInput,
                                onValueChange = { quantityInput = it },
                                label = { Text("Jumlah Rusak / Busuk (Maks: ${String.format("%.1f", selectedFruit.stock)} ${selectedFruit.unit})") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                placeholder = { Text("0.0") },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )

                            // Select Reason dropdown
                            Box(modifier = Modifier.fillMaxWidth()) {
                                OutlinedTextField(
                                    value = selectedReason,
                                    onValueChange = {},
                                    label = { Text("Keterangan Kerusakan") },
                                    readOnly = true,
                                    trailingIcon = {
                                        IconButton(onClick = { reasonDropdownExpanded = true }) {
                                            Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth().clickable { reasonDropdownExpanded = true }
                                )
                                DropdownMenu(
                                    expanded = reasonDropdownExpanded,
                                    onDismissRequest = { reasonDropdownExpanded = false }
                                ) {
                                    reasons.forEach { res ->
                                        DropdownMenuItem(
                                            text = { Text(res) },
                                            onClick = {
                                                selectedReason = res
                                                reasonDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }

                            if (quantity > selectedFruit.stock) {
                                Text(
                                    "Jumlah rusak tidak boleh melebihi stok tersedia (${selectedFruit.stock} ${selectedFruit.unit})!",
                                    color = MaterialTheme.colorScheme.error,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }

        // Live calculation losses
        if (isFormValid && selectedFruit != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("Total Taksiran Kerugian (Modal Masuk)", fontSize = 12.sp, color = MaterialTheme.colorScheme.onErrorContainer)
                            Text(
                                text = formatRupiah(totalLoss),
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.error
                            )
                        }
                        Icon(Icons.Default.BrokenImage, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }

        // Save Button
        if (fruitOptions.isNotEmpty()) {
            item {
                Button(
                    onClick = {
                        if (isFormValid && selectedFruit != null) {
                            viewModel.reportDamage(
                                fruitId = selectedFruit.id,
                                quantity = quantity,
                                reason = selectedReason,
                                timestamp = System.currentTimeMillis()
                            )
                            // Clear inputs
                            selectedIndex = -1
                            quantityInput = ""
                            selectedReason = "busuk"
                        }
                    },
                    enabled = isFormValid,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    ),
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.DeleteForever, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Catat Kerugian Buah", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}

// -----------------------------------------------------
// 6. GRAFIK PENJUALAN SCREEN (CHART)
// -----------------------------------------------------
@Composable
fun GrafikScreen(viewModel: MainViewModel) {
    val chartData by viewModel.lastDaysChartData.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text(
                "Grafik Penjualan Harian",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                "Omzet penjualan & keuntungan bersih dalam 7 hari terakhir.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }

        if (chartData.isEmpty() || chartData.all { it.totalSales == 0.0 }) {
            Box(
                modifier = Modifier.fillMaxSize().weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Icon(
                        Icons.Default.InsertChartOutlined,
                        contentDescription = null,
                        modifier = Modifier.size(56.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
                    )
                    Text(
                        text = "Data grafik masih kosong.\nSilakan catat penjualan untuk memunculkan grafik!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                modifier = Modifier.fillMaxWidth().height(300.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    // Legends
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterHorizontally),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(12.dp).background(Color(0xFF2E7D32), RoundedCornerShape(2.dp)))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Omzet Penjualan", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(12.dp).background(Color(0xFFEF6C00), RoundedCornerShape(2.dp)))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Keuntungan", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Draw Canvas Chart
                    val maxVal = maxOf(1000.0, chartData.maxOf { maxOf(it.totalSales, it.totalProfit) })
                    val labelColor = MaterialTheme.colorScheme.onSurface.toArgb()
                    val gridColor = MaterialTheme.colorScheme.outlineVariant.toArgb()

                    Canvas(
                        modifier = Modifier.fillMaxSize().weight(1f)
                    ) {
                        val width = size.width
                        val height = size.height
                        val bottomPadding = 48f
                        val topPadding = 24f
                        val leftPadding = 40f
                        
                        val chartHeight = height - bottomPadding - topPadding
                        val chartWidth = width - leftPadding

                        // Draw background grid lines (Y levels: 0, 50%, 100%)
                        val linesY = listOf(topPadding, topPadding + chartHeight * 0.5f, topPadding + chartHeight)
                        linesY.forEach { yValue ->
                            drawLine(
                                color = Color(gridColor).copy(alpha = 0.5f),
                                start = Offset(leftPadding, yValue),
                                end = Offset(width, yValue),
                                strokeWidth = 1f
                            )
                        }

                        // Draw vertical elements
                        val slotWidth = chartWidth / 7
                        val barWidth = slotWidth * 0.32f

                        chartData.forEachIndexed { index, day ->
                            val xOffset = leftPadding + (index * slotWidth)
                            
                            // Scale values
                            val salesHeight = ((day.totalSales / maxVal) * chartHeight).toFloat()
                            val profitHeight = ((day.totalProfit / maxVal) * chartHeight).toFloat()

                            // Coordinates
                            val ySales = topPadding + chartHeight - salesHeight
                            val xSales = xOffset + slotWidth * 0.15f

                            val yProfit = topPadding + chartHeight - profitHeight
                            val xProfit = xOffset + slotWidth * 0.52f

                            // Draw Sales Bar (Green)
                            if (day.totalSales > 0.0) {
                                drawRect(
                                    color = Color(0xFF2E7D32),
                                    topLeft = Offset(xSales, ySales),
                                    size = Size(barWidth, salesHeight)
                                )
                                // Text above sales bar (Brief value if space permits)
                                drawContext.canvas.nativeCanvas.drawText(
                                    if (day.totalSales >= 1000000) "${String.format("%.1f", day.totalSales/1000000)}jt" else "${(day.totalSales/1000).toInt()}k",
                                    xSales + barWidth/2f,
                                    ySales - 6f,
                                    android.graphics.Paint().apply {
                                        color = labelColor
                                        textSize = 18f
                                        textAlign = android.graphics.Paint.Align.CENTER
                                        isAntiAlias = true
                                    }
                                )
                            }

                            // Draw Profit Bar (Orange)
                            if (day.totalProfit > 0.0) {
                                drawRect(
                                    color = Color(0xFFEF6C00),
                                    topLeft = Offset(xProfit, yProfit),
                                    size = Size(barWidth, profitHeight)
                                )
                                // Text above profit bar
                                if (day.totalProfit > 1000.0) {
                                    drawContext.canvas.nativeCanvas.drawText(
                                        if (day.totalProfit >= 1000000) "${String.format("%.1f", day.totalProfit/1000000)}jt" else "${(day.totalProfit/1000).toInt()}k",
                                        xProfit + barWidth/2f,
                                        yProfit - 6f,
                                        android.graphics.Paint().apply {
                                            color = Color(0xFFEF6C00).toArgb()
                                            textSize = 18f
                                            textAlign = android.graphics.Paint.Align.CENTER
                                            isAntiAlias = true
                                        }
                                    )
                                }
                            }

                            // Day Label dd/mm
                            drawContext.canvas.nativeCanvas.drawText(
                                day.label,
                                xOffset + slotWidth/2f,
                                height - 12f,
                                android.graphics.Paint().apply {
                                    color = labelColor
                                    textSize = 22f
                                    textAlign = android.graphics.Paint.Align.CENTER
                                    typeface = android.graphics.Typeface.DEFAULT_BOLD
                                    isAntiAlias = true
                                }
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Text summary card
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Total Penjualan 7 Hari: " + formatRupiah(chartData.sumOf { it.totalSales }), fontWeight = FontWeight.Bold)
                    Text("Total Keuntungan 7 Hari: " + formatRupiah(chartData.sumOf { it.totalProfit }), fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
                }
            }
        }
    }
}

// -----------------------------------------------------
// 7. RIWAYAT TRANSAKSI SCREEN
// -----------------------------------------------------
@Composable
fun RiwayatScreen(viewModel: MainViewModel) {
    val transactions by viewModel.transactionsState.collectAsStateWithLifecycle()
    var selectedTypeFilter by remember { mutableStateOf("SEMUA") } // "SEMUA", "MASUK", "KELUAR", "RUSAK"

    var showConfirmResetDialog by remember { mutableStateOf(false) }

    if (showConfirmResetDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmResetDialog = false },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.resetAllData()
                        showConfirmResetDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    )
                ) {
                    Text("Ya, Hapus Semua")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmResetDialog = false }) {
                    Text("Batal")
                }
            },
            title = { Text("Risiko Tinggi: Reset Seluruh Data") },
            text = { Text("Apakah Anda yakin ingin menghapus seluruh data stok dan riwayat transaksi Aplikasi Gerai Ku? Tindakan ini permanen dan tidak dapat dibatalkan!") }
        )
    }

    val filteredTransactions = when (selectedTypeFilter) {
        "SEMUA" -> transactions
        else -> transactions.filter { it.type == selectedTypeFilter }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title & Reset button Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Riwayat Transaksi Gerai",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            IconButton(
                onClick = { showConfirmResetDialog = true },
                modifier = Modifier.testTag("reset_data_button")
            ) {
                Icon(Icons.Default.DeleteSweep, contentDescription = "Reset Aplikasi", tint = MaterialTheme.colorScheme.error)
            }
        }

        // Filter chips row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val filters = listOf("SEMUA", "MASUK", "KELUAR", "RUSAK")
            filters.forEach { filter ->
                val isSelected = selectedTypeFilter == filter
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedTypeFilter = filter },
                    label = { Text(filter) }
                )
            }
        }

        // Transactions list
        if (filteredTransactions.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().weight(1f),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Belum ada transaksi di riwayat perekaman.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize().weight(1f)
            ) {
                items(filteredTransactions) { txn ->
                    TransactionItemRow(txn)
                }
            }
        }
    }
}

@Composable
fun TransactionItemRow(txn: TransactionEntity) {
    val (typeColor, typeLabel, typeIcon) = when (txn.type) {
        "MASUK" -> Triple(Color(0xFF2E7D32), "Masuk", Icons.Default.AddCircleOutline)
        "KELUAR" -> Triple(Color(0xFF0288D1), "Keluar / Jual", Icons.Default.CheckCircleOutline)
        else -> Triple(MaterialTheme.colorScheme.error, "Rusak / Busuk", Icons.Default.RemoveCircleOutline)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        border = androidx.compose.foundation.BorderStroke(1.dp, typeColor.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            // Header Row: Type and datetime
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(typeIcon, contentDescription = null, tint = typeColor, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(typeLabel, fontWeight = FontWeight.Bold, color = typeColor, fontSize = 12.sp)
                }
                Text(formatDateTime(txn.timestamp), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            // Central Detail
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text(txn.fruitName, fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurface)
                    Text(
                        text = "Jumlah: ${String.format("%.1f", txn.quantity)} ${txn.unit} @ ${formatRupiah(txn.pricePerUnit)}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                
                // Total Transaction Amount
                Text(
                    text = (if (txn.type == "RUSAK") "- " else "") + formatRupiah(txn.totalAmount),
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = if (txn.type == "RUSAK") MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface
                )
            }

            // Bottom Extra Details
            when (txn.type) {
                "KELUAR" -> {
                    val cost = txn.quantity * (txn.buyPricePerUnit ?: 0.0)
                    val prof = txn.totalAmount - cost
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(Color(0xFFF9F9F9), RoundedCornerShape(4.dp))
                            .padding(6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Modal Terjual: ${formatRupiah(cost)}", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(
                            text = "Laba: ${formatRupiah(prof)}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (prof >= 0) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                        )
                    }
                }
                "RUSAK" -> {
                    if (!txn.notes.isNullOrBlank()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                .padding(6.dp)
                        ) {
                            Text(
                                "Keterangan: ${txn.notes}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.error,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }
}
