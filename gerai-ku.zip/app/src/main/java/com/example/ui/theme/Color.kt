package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Organic Palette (Gerai Ku)
val FruitGreenPrimary = Color(0xFF2D5A27) // Professional Deep Green
val FruitGreenSecondary = Color(0xFFF97316) // Energetic theme orange
val FruitOrangeTertiary = Color(0xFFFFB74D) // Soft Peach
val LightBackground = Color(0xFFF7F9F7) // Professional Polish background
val LightSurface = Color(0xFFFFFFFF) // Professional white card surface
val LightSurfaceVariant = Color(0xFFE2E8F0) // Subtle Slate border
val LightOnPrimary = Color(0xFFFFFFFF)
val LightOnSecondary = Color(0xFFFFFFFF)

// Dark Theme Organic Palette (Gerai Ku)
val FruitGreenPrimaryDark = Color(0xFF81C784) // Lighter green for darkmode
val FruitGreenSecondaryDark = Color(0xFFFFB74D) // Warm peach
val FruitOrangeTertiaryDark = Color(0xFFFFCC80)
val DarkBackground = Color(0xFF11140F) // Dark organic forest
val DarkSurface = Color(0xFF1A1D17) // Dark sage
val DarkSurfaceVariant = Color(0xFF272C21) // Muted dark green
val DarkOnPrimary = Color(0xFF0F3112)
val DarkOnSecondary = Color(0xFF5D2500)

// Existing colors to maintain compatibility if referenced anywhere
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
