package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    @Query("SELECT * FROM fruits ORDER BY name ASC")
    fun getAllFruits(): Flow<List<FruitEntity>>

    @Query("SELECT * FROM fruits WHERE id = :id LIMIT 1")
    suspend fun getFruitById(id: Int): FruitEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFruit(fruit: FruitEntity): Long

    @Update
    suspend fun updateFruit(fruit: FruitEntity)

    @Delete
    suspend fun deleteFruit(fruit: FruitEntity)

    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity)

    @Query("DELETE FROM fruits")
    suspend fun deleteAllFruits()

    @Query("DELETE FROM transactions")
    suspend fun deleteAllTransactions()

    @Transaction
    suspend fun clearAllData() {
        deleteAllFruits()
        deleteAllTransactions()
    }
}
