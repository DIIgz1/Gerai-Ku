package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "fruits")
data class FruitEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val stock: Double,
    val unit: String,
    val buyPrice: Double,
    val sellPrice: Double,
    val entryDate: Long,
    val expiryDate: Long
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String, // "MASUK", "KELUAR", "RUSAK"
    val fruitName: String,
    val quantity: Double,
    val unit: String,
    val pricePerUnit: Double, // buy price for MASUK/RUSAK, sell price for KELUAR
    val totalAmount: Double,  // quantity * pricePerUnit (sales, capital, or loss)
    val timestamp: Long,
    val buyPricePerUnit: Double? = null, // for COGS calculations
    val notes: String? = null // only for RUSAK
)
