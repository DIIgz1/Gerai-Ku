package com.example.data

import kotlinx.coroutines.flow.Flow

class AppRepository(private val dao: AppDao) {
    val allFruits: Flow<List<FruitEntity>> = dao.getAllFruits()
    val allTransactions: Flow<List<TransactionEntity>> = dao.getAllTransactions()

    suspend fun insertFruit(fruit: FruitEntity): Long {
        return dao.insertFruit(fruit)
    }

    suspend fun updateFruit(fruit: FruitEntity) {
        dao.updateFruit(fruit)
    }

    suspend fun deleteFruit(fruit: FruitEntity) {
        dao.deleteFruit(fruit)
    }

    suspend fun getFruitById(id: Int): FruitEntity? {
        return dao.getFruitById(id)
    }

    suspend fun logGoodsEntry(
        name: String,
        quantity: Double,
        unit: String,
        buyPrice: Double,
        sellPrice: Double,
        entryDate: Long,
        expiryDate: Long
    ) {
        // 1. Create the new Fruit Stock Entry
        val fruit = FruitEntity(
            name = name,
            stock = quantity,
            unit = unit,
            buyPrice = buyPrice,
            sellPrice = sellPrice,
            entryDate = entryDate,
            expiryDate = expiryDate
        )
        dao.insertFruit(fruit)

        // 2. Insert the MASUK transaction log
        val transaction = TransactionEntity(
            type = "MASUK",
            fruitName = name,
            quantity = quantity,
            unit = unit,
            pricePerUnit = buyPrice,
            totalAmount = quantity * buyPrice,
            timestamp = entryDate
        )
        dao.insertTransaction(transaction)
    }

    suspend fun logSale(
        fruitId: Int,
        quantity: Double,
        soldPricePerUnit: Double,
        timestamp: Long
    ): Boolean {
        val fruit = dao.getFruitById(fruitId) ?: return false
        if (fruit.stock < quantity) return false

        val newStock = fruit.stock - quantity
        if (newStock <= 0.0) {
            dao.deleteFruit(fruit)
        } else {
            dao.updateFruit(fruit.copy(stock = newStock))
        }

        val transaction = TransactionEntity(
            type = "KELUAR",
            fruitName = fruit.name,
            quantity = quantity,
            unit = fruit.unit,
            pricePerUnit = soldPricePerUnit,
            totalAmount = quantity * soldPricePerUnit,
            timestamp = timestamp,
            buyPricePerUnit = fruit.buyPrice
        )
        dao.insertTransaction(transaction)
        return true
    }

    suspend fun logDamage(
        fruitId: Int,
        quantity: Double,
        reason: String,
        timestamp: Long
    ): Boolean {
        val fruit = dao.getFruitById(fruitId) ?: return false
        if (fruit.stock < quantity) return false

        val newStock = fruit.stock - quantity
        if (newStock <= 0.0) {
            dao.deleteFruit(fruit)
        } else {
            dao.updateFruit(fruit.copy(stock = newStock))
        }

        val transaction = TransactionEntity(
            type = "RUSAK",
            fruitName = fruit.name,
            quantity = quantity,
            unit = fruit.unit,
            pricePerUnit = fruit.buyPrice,
            totalAmount = quantity * fruit.buyPrice,
            timestamp = timestamp,
            notes = reason
        )
        dao.insertTransaction(transaction)
        return true
    }

    suspend fun clearAllData() {
        dao.clearAllData()
    }
}
